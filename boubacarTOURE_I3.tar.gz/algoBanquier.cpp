#include <iostream>
#include <array>

//			CRÉATION DE PROCESSUS
const int nbResMax = 10;							//Le nombre de ressources différents doit être (nbResMax <= 10)
using element = int;
using Tab = std::array <element, nbResMax>;
struct Processus {
	Tab Allocation;					//Tableau contenant l'espace alloué par notre processus
	Tab Maximum;					//Tableau contenant l'espace maximum pouvant être alloué par notre processus
	Tab Besoin;						//Tableau contenant les espaces manquants à notre processus pour se terminer
	Tab Demande;					//Tableau contenant les demandes de ressources pour notre processus
	bool Terminer;					//Détermine si un processus a fini son exécution ou pas
};

//			CRÉATION DU SYSTEME
const int nbProcMax = 5;							//Le nombre de processus lancé en même temps sur notre systeme doit être (nbProcMax <= 5)
using element2 = Processus;
using TabProcessus = std::array<element2, nbProcMax>;
struct Systeme {
	TabProcessus leProcessus;			//Tableau contenant cinq (5) processus à l'état initial
	Tab Quantite;						//Tableau contenant la quantité maximum des ressources de notre systeme (Demandé à l'utilisateur)
	Tab Disponible;						//Tableau contenant les ressources maximum disponibles de notre systeme
	Tab Sequence;						//Tableau contenant les séquences de déroulement des processus pour être dans un état sûr
	int nbProcessus;					//Le nombre de processus utilisable sur notre systeme ("nbProcessus = 5")
	int nbRessource;					//Le nombre de ressources utilisable sur notre systeme (Demandé à l'utilisateur)
};
void initialiseSystem (Systeme &S,int nbRes) {
//Cette fonction a pour but de créer un systeme contenant 5 processus tout en initialisant le nombre processus et de ressources utiles
	Processus p0, p1, p2, p3, p4;
	p0.Terminer = false; p1.Terminer = false; p2.Terminer = false; p3.Terminer = false; p4.Terminer = false; 
	S.leProcessus[0] = p0; S.leProcessus[1] = p1; S.leProcessus[2] = p2; S.leProcessus[3] = p3; S.leProcessus[4] = p4;
	S.nbProcessus = 5;
	S.nbRessource = nbRes;
	S.Sequence[0] = -1;
}

void creerSysteme (Systeme &S) {		//Demande le nombre de ressource à l'utilisateur puis crée un systeme correspondant aux données saisies
	int nbRes = 0;
	std::cout << "Veuillez saisir le nombre de ressources différents utiles (nbRessource < 10) : ";
	do {
		std::cin >> nbRes;
		if (nbRes <= 0 || nbRes > 10) std::cout << "Le nombre de ressources doit être compris entre [1,10] : ";
	} while (nbRes <= 0 || nbRes > 10);
	std::cout << "Le nombre de ressources utiles pour nos cinq (5) processus est : " << nbRes << std::endl;
	initialiseSystem(S,nbRes);
	std::cout << std::endl;
}

void saisieQuantiteRessource (Systeme &S) {			//Permet à l'utilisateur de saisir les ressources disponibles sur le système
	std::cout << "Veuillez saisir la quantité maximum initiale des " << S.nbRessource << " ressources du système (Matrice QUANTITÉ INITIALE)" << std::endl;
	for (int j = 0; j < S.nbRessource; j++) {
		do {
			std::cin >> S.Disponible[j];
			if (S.Disponible[j] < 0) std::cout << "La ressource ne doit pas être négatif, reprenez : ";
		} while (S.Disponible[j] < 0);
		std::cout << "Ok pour la " << j+1 << "ème ressources" << std::endl;
		S.Quantite[j] = S.Disponible[j];
	}	std::cout << std::endl;
}

void saisieMaximumAllocation (Systeme &S) {			//Permet à l'utilisateur de saisir les ressources maximum occupable sur le système pour chaque processus
	std::cout << "Veuillez saisir les ressources maximum allouable par chaque processus pour les " << S.nbRessource << " ressources du système (Matrice MAXIMUM)" << std::endl;
	for (int i = 0; i < S.nbProcessus; i++) {
		std::cout << "Pour le " << i+1 << "ème processus : " << std::endl;
		for (int j = 0; j < S.nbRessource; j++) {
			do {
				std::cin >> S.leProcessus[i].Maximum[j];
				if (S.leProcessus[i].Maximum[j] > S.Quantite[j] || S.leProcessus[i].Maximum[j] < 0)
					std::cout << "L'espace allouable doit être compris entre [0," <<  S.Quantite[j] << "] : ";
			} while (S.leProcessus[i].Maximum[j] > S.Quantite[j] || S.leProcessus[i].Maximum[j] < 0);
			std::cout << "Ok pour la " << j+1 << "ème ressources du Processus" << std::endl;
		}
	}	std::cout << std::endl;
}

void saisieAllocationRessource (Systeme &S) {			//Permet à l'utilisateur de saisir les ressources occupées sur le système pour chaque processus
	bool nonSure = false;
	std::cout << "Veuillez saisir les ressources allouées par chaque processus pour les " << S.nbRessource << " ressources du système (Matrice ALLOCATION)" << std::endl;
	for (int i = 0; i < S.nbProcessus; i++) {
		std::cout << "Pour le " << i+1 << "ème processus : " << std::endl;
		for (int j = 0; j < S.nbRessource; j++) {
			do {
				std::cin >> S.leProcessus[i].Allocation[j];
				if (S.leProcessus[i].Allocation[j] > S.leProcessus[i].Maximum[j] || S.leProcessus[i].Allocation[j] < 0)
					std::cout << "L'espace allouable doit être compris entre [0," <<  S.leProcessus[i].Maximum[j] << "] : ";
			} while (S.leProcessus[i].Allocation[j] > S.leProcessus[i].Maximum[j] || S.leProcessus[i].Allocation[j] < 0);
			std::cout << "Ok pour la " << j+1 << "ème ressources du Processus" << std::endl;
			//LES CALCULS QUI DOIVENT SE PRODUIRE APRÈS L'ALLOCATION DE RESSOURCES
			S.leProcessus[i].Besoin[j] = S.leProcessus[i].Maximum[j] - S.leProcessus[i].Allocation[j];
			S.Disponible[j] -= S.leProcessus[i].Allocation[j];
			if (S.Disponible[j] < 0) nonSure = true;
		}
	} if (nonSure) std::cout << "Vous êtes dans un état non Sure " << std::endl;
	std::cout << std::endl;
}

void afficheDispoMaxAllocBesoin (Systeme S) {					//Permet d'afficher les données des matrices Disponibles, Maximum, Allocation et Besoin
	std::cout << "Affichons les données des matrices DISPONIBLE INITIAL, MAXIMUM, ALLOCATION, TERMINER et DISPONIBLE chaque processus du système : " << std::endl;
	std::cout << "Pour la matrice DISPONIBLE INITIAL : " << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << "R" << i+1 << "	";
	std::cout << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << S.Quantite[i] << "	";
	std::cout << std::endl; std::cout << std::endl;

	std::cout << "Pour la matrice MAXIMUM : " << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << "R" << i+1 << "	";
	std::cout << std::endl;
	for (int i = 0; i < S.nbProcessus; i++) {
		for (int j = 0; j < S.nbRessource; j++) {
			std::cout << S.leProcessus[i].Maximum[j] << "	";
		} std::cout << std::endl;
	} std::cout << std::endl;

	std::cout << "Pour la matrice ALLOCATION : " << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << "R" << i+1 << "	";
	std::cout << std::endl;
	for (int i = 0; i < S.nbProcessus; i++) {
		for (int j = 0; j < S.nbRessource; j++) {
			std::cout << S.leProcessus[i].Allocation[j] << "	";
		} std::cout << std::endl;
	} std::cout << std::endl;

	std::cout << "Pour la matrice BESOIN : " << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << "R" << i+1 << "	";
	std::cout << std::endl;
	for (int i = 0; i < S.nbProcessus; i++) {
		for (int j = 0; j < S.nbRessource; j++) {
			std::cout << S.leProcessus[i].Besoin[j] << "	";
		} std::cout << std::endl;
	} std::cout << std::endl;

	std::cout << "Pour la matrice TERMINER : " << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << "R" << i+1 << "	";
	std::cout << std::endl;
	for (int i = 0; i < S.nbProcessus; i++) {
		for (int j = 0; j < S.nbRessource; j++) {
			if (S.leProcessus[i].Terminer) std::cout << 0 << "	";
			else std::cout << 1 << "	";
		} std::cout << std::endl;
	} std::cout << std::endl;
	
	std::cout << "Pour la matrice DISPONIBLE après l'allocation : " << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << "R" << i+1 << "	";
	std::cout << std::endl;
	for (int i = 0; i < S.nbRessource; i++)	std::cout << S.Disponible[i] << "	";
	std::cout << std::endl; std::cout << std::endl;
}

bool estTerminer(int numProcessus, Systeme S) {				//Teste si le processus 'numProcessus' est terminé sur le Systeme
	int compteur = 0;
	for (int j = 0; j < S.nbRessource; j++)
		if (S.leProcessus[numProcessus].Terminer == true || (S.leProcessus[numProcessus].Allocation[j] == 0 && S.leProcessus[numProcessus].Besoin[j] == 0)) ++compteur;
	if (compteur == S.nbRessource) return true;
	else return false;
}

bool processusExecutable(int numProcessus, Systeme S) {		//Teste si le processus 'numProcessus' peut s'exécuter sur le Systeme
	bool trouver = true, trouver2 = false;
	for (int j = 0; j < S.nbRessource; j++) {
		if (S.leProcessus[numProcessus].Besoin[j] != 0) trouver = false;
		if (S.leProcessus[numProcessus].Allocation[j] != 0) trouver2 = true;
	}
	if(trouver && trouver2) return true;
	else return false;
}

void termineProcessus (int numProcessus, Systeme &S) {		//Permet de terminer le processus 'numProcessus' s'il est terminé sur le Systeme
	if(estTerminer(numProcessus,S)) S.leProcessus[numProcessus].Terminer = true;
	else S.leProcessus[numProcessus].Terminer = false;
}

bool trouveNonTerminer (Systeme S) {						//Teste s'il y a un processus non terminé sur le systeme
	int compteur = 0;
	for (int i = 0; i < S.nbProcessus; i++)
		if (estTerminer(i,S)) ++compteur;
	if (compteur == S.nbProcessus) return false;
	else return true;
}

bool dispoTest (int numProcessus, Systeme S, Tab DispoTest) {	//Determine si les ressources disponibles dans DispoTest peuvent satisfaire numProcessus sur le systeme
	bool trouver = true; int j = 0;
	while (j < S.nbRessource && trouver) {
		if (S.leProcessus[numProcessus].Besoin[j] > DispoTest[j]) return false;
		++j;
	}
	return true;
}

int trouveProcessus (Systeme S, Tab DispoTest) {		//Renvoi la position du 1er processus non terminé pouvant exécuter avec l'espace disponible sur le systeme
	for (int i = 0; i < S.nbProcessus; i++)
		if (!estTerminer(i,S) && dispoTest(i,S,DispoTest)) return i;
	return -1;
}

void afficheSequence (Systeme S) {						//Permet d'afficher la sequence de déroulement d'un processus dans un état sûr 
	if (S.Sequence[0] != -1) {
		if (S.Sequence[0] < 5 && S.Sequence[0] >= 0) std::cout << "|P" << S.Sequence[0]+1 << "| ==> ";
		for (int j = 1; j < S.nbProcessus-1; j++)
			if (S.Sequence[j] < 5 && S.Sequence[j] >= 0) std::cout << "P" << S.Sequence[j]+1 << "| ==> ";
		if (S.Sequence[S.nbProcessus-1] < 5 && S.Sequence[S.nbProcessus-1] >= 0) std::cout << "P" << S.Sequence[S.nbProcessus-1]+1;
	} else std::cout << "Il n'y a pas de séquences possible avec ses ressources pour rester dans un état sûr. (-_-)";
}

bool testSur (Systeme &ST) {					//Determine si les demandes d'un processus permet au systeme de rester dans un etat sure
	Tab Seq; int k = 0, n = 0; bool fait = false;
	Systeme S = ST;
	if (trouveNonTerminer(S)) {
		Tab DispoTest = S.Disponible;
		while (trouveProcessus(S,DispoTest) >= 0) {
			n = trouveProcessus(S,DispoTest);
			for (int i = 0; i < S.nbRessource; i++) {
				DispoTest[i] += S.leProcessus[n].Allocation[i];
				S.leProcessus[n].Allocation[i] = 0;
				S.leProcessus[n].Besoin[i] = 0;
			}
			termineProcessus(n,S);
			Seq[k++] = n;
		}
		if (trouveProcessus(S,DispoTest) < 0 && !trouveNonTerminer(S)) {
			if (!fait) {ST.Sequence = Seq; fait = true; }
			std::cout << "La séquence de déroulement des processus qui permet de rester dans un état sûr : ("; afficheSequence(ST); std::cout << ")" << std::endl;
			return true;
		}
		else { std::cout << "Les ressources disponibles seront insuffisantes pour les processus du système" << std::endl; return false; }
	} else return true;
}

void demandeRessource (Systeme &S) {		//Permet de demander des ressources au processus numProcessus
	int numProcessus;
	std::cout << "Veuillez saisir le numéro du processus utile (comprise entre [1," << S.nbProcessus << "]) : ";
	do {
		std::cin >> numProcessus;
		if (numProcessus <= 0 || numProcessus > S.nbProcessus ) std::cout << "Le numéro du processus doit être compris entre [1," << S.nbProcessus << "] : ";
		else if (estTerminer(numProcessus-1,S)) std::cout << "Le processus est déjà exécuté, choisissez un autre : ";
	} while (numProcessus <= 0 || numProcessus > S.nbProcessus || estTerminer(numProcessus-1,S));
	std::cout << "Veuillez saisir les ressources utiles au processus n°" << numProcessus << " pour chaque ressource (DEMANDE DU PROCESSUS): ";
	--numProcessus; int n1 = 0;
	for (int i = 0; i < S.nbRessource; i++) {
		do {
			std::cin >> n1;
			if (n1 > S.leProcessus[numProcessus].Besoin[i] || n1 < 0)
				std::cout << "Impossible, les ressources allouables doivent être inférieure ou egal à votre besoin (comprises entre [0," << S.leProcessus[numProcessus].Besoin[i] << "]) : ";
		} while (n1 > S.leProcessus[numProcessus].Besoin[i] || n1 < 0);
		S.leProcessus[numProcessus].Demande[i] = n1;
		S.leProcessus[numProcessus].Allocation[i] += n1;
		S.leProcessus[numProcessus].Besoin[i] -= n1;
		S.Disponible[i] -= n1;
	}
	if (testSur(S)) {
		std::cout << "La demande du processus n°" << numProcessus+1 << " nous permet de rester dans un état sûr (^_^)" << std::endl;
		for(int i = 0; i < S.nbRessource; i++) {
			if (processusExecutable(numProcessus,S)) {
				S.Disponible[i] += S.leProcessus[numProcessus].Allocation[i];
				S.leProcessus[numProcessus].Allocation[i] = 0;
			}
			termineProcessus(numProcessus,S);
		}
	}
	else {
		std::cout << "La demande du processus n°" << numProcessus+1 << " ne nous permet donc pas de rester dans un état sûr (-_-). DESOLE MAIS J'ANNULE VOTRE DEMANDE" << std::endl;
		for (int i = 0; i < S.nbRessource; i++) {
			S.leProcessus[numProcessus].Allocation[i] -= S.leProcessus[numProcessus].Demande[i];
			S.leProcessus[numProcessus].Besoin[i] += S.leProcessus[numProcessus].Demande[i];
			S.Disponible[i] += S.leProcessus[numProcessus].Demande[i];
			S.leProcessus[numProcessus].Demande[i] = 0;
		}
	} std::cout << std::endl;
}

	/**
	 * ##################################################
	 * 				PROGRAMME PRINCIPAL
	 * ##################################################
	*/
int main () {
	std::cout << std::endl;
	std::cout << "######		Début de l'algorithme du banquier (On dispose de 5 procéssus déja defini)	######" << std::endl;
	std::cout << std::endl;
	//		DECLARATION DES VARIABLES
	Systeme S; int n = 0, t = 0;
	//		DEBUT DE L'ALGORITHME DU BANQUIER
	std::cout << "--------SAISIE DES DONNÉES DE RESSOURCES DU SYSTÈME----------" << std::endl;
	
	std::cout << "*##################################################################################################" << std::endl;
	std::cout << "*# Vous pouvez copiez directement ceci dans le terminal	pour l'exemple du TD5 (la partie cours) " << std::endl;
	std::cout << "*# 			3 10 5 7 7 5 3 3 2 2 9 0 2 2 2 2 4 3 3 0 1 0 2 0 0 3 0 2 2 1 1 0 0 2			 	" << std::endl;
	std::cout << "*# 				Ou faire un par par pour chaque demande saisi au clavier (^_^)		 			" << std::endl;
	std::cout << "*##################################################################################################" << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	
	std::cout << "*##################################################################################################" << std::endl;
	std::cout << "*#		Vous pouvez copiez directement ceci dans le terminal pour l'exemple du TD5				" << std::endl;
	std::cout << "*# 4 3 14 12 12 0 0 1 2 1 7 5 0 2 3 5 6 0 6 5 2 0 6 5 6 0 0 1 2 1 0 0 0 1 3 5 4 0 6 3 2 0 0 1 4	" << std::endl;
	std::cout << "*# 				Ou faire un par par pour chaque demande saisi au clavier (^_^)		 			" << std::endl;
	std::cout << "*##################################################################################################" << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	creerSysteme(S);					//Vous pouvez copiez directement cela dans le terminal	     ====>	 	4
	saisieQuantiteRessource(S);			//Vous pouvez copiez directement cela dans le terminal	     ====>	 	3 14 12 12
	saisieMaximumAllocation(S);			//Vous pouvez copiez directement cela dans le terminal	     ====>	 	0 0 1 2 1 7 5 0 2 3 5 6 0 6 5 2 0 6 5 6
	saisieAllocationRessource(S);		//Vous pouvez copiez directement cela dans le terminal	     ====>	 	0 0 1 2 1 0 0 0 1 3 5 4 0 6 3 2 0 0 1 4
	afficheDispoMaxAllocBesoin(S);
	/**
	*	Vous auriez le nom de chaque ressources representé par la mettre R(i) avec i le numero de la ressource
	*	Chaque ligne correspond aux données pour le processus correspondant à la ligne
	* 	Exemple, pour le 1er processus, ses données seront présentent sur la 1re ligne
	* 	pour le 2e, se sera sur la 2e ligne etc.
	*/
	std::cout << "--------DEMANDE DE RESSOURCES POUR UN PROCESSUS----------" << std::endl;
	std::cout << "Combien de demande de ressources souhaitez-vous faire ? ";
	std::cin >> t;
	std::cout << "*######################################################################################################" << std::endl;
	std::cout << "*# LA SEQUENCE DE DEROULEMENT PERMETTANT DE RESTER DANS UN ETAT SURE SERAIT AUTOMATIQUEMENT MISE A JOUR " << std::endl;
	std::cout << "*# LA PREMIERE SEQUENCE PERMETTANT DE RESTER DANS UN ETAT SURE EST LA SEQUENCE INITIALE, ET LE PROCESSUS" << std::endl;
	std::cout << "*# COURANT QUI VIENT D'ETRE LANCER EST ENCADRÉ PAR |p1| ET LES AUTRES SERONT TOUT SIMPLEMENT PRIS PAR   " << std::endl;
	std::cout << "*# CECI |. EXEMPLE DE SEQUENCE (P1,P2,P3,P4) APRES LEXÉCUTION DE P1 : |P1|=>P2|=>P3|=>P4				  " << std::endl;
	std::cout << "*######################################################################################################" << std::endl;
	std::cout << std::endl;
	while (n < t && trouveNonTerminer(S)) {
		std::cout << n+1 << "ÈME ESSAI (IL VOUS RESTE " << t-(n+1) << " ESSAI) " << std::endl;
		std::cout << std::endl;
		demandeRessource(S);
		afficheDispoMaxAllocBesoin(S);
		++n;
	}
	if (!trouveNonTerminer(S)) std::cout << "FELICITATION TOUTES LES PROCESSUS ONT ÉTÉ EXÉCUTÉ AVEC SUCCÈS (^_^). MERCI ET AUREVOIR !!!" << std::endl;
	//		FIN DE L'ALGORITHME DU BANQUIER
	std::cout << std::endl;
	std::cout << "######		fin de l'algorithme du banquier 	######" << std::endl;
	std::cout << std::endl;

	return 0;
}
