#include <iostream>
#include <array>

	/*	############	CREATION D'UNE PAGE	###############	*/
struct Page {
   int reference;
   int numeroPage;
};

void creerPage (Page &p, int i) {			// Return une page avec i comme numero de Page
	p.reference = 0;
	p.numeroPage = i;
}

bool refNull (Page p)				//Teste si la reference de la page est null
{	return p.reference <= 0; }

void affichePage (Page p) {			//Affiche les informations de la page
	std::cout << "Le numéro de la page : " << p.numeroPage << std::endl;
	std::cout << "La référence de la page : " << p.reference << std::endl;
}

void saisiePage (Page &p) {			//Permet de créer les pages
	int n;
	std::cout << "Veuillez saisir le numéro de la page à inserer dans la page de référencement : ";
	std::cin >> n;
	creerPage(p,n);
	std::cout << "La page n°" << p.numeroPage << " a été créé " << std::endl;
}

	/*	###########	CREATION D'UNE REFERENCE DE PAGE	###############	*/
struct maillon {
	Page page;
	maillon* suiv;
};
using referenceDePage = maillon*;					//Reference de Pages (contient la liste des pages à inserer en mémoire)

void initRef (referenceDePage &R ) 					//Initialise la liste de référence à NULL
{	R = nullptr; }

bool referenceVide(referenceDePage R) 				//Verifie si la liste des pages est vide
{	return R == nullptr; }

void ajouter(Page p, referenceDePage &R) {
	referenceDePage R1 = new maillon;
	R1->page = p;
	R1->suiv = R;
	R = R1;
}
void ajouterPage (Page p, referenceDePage &R) {		//Ajoute une page en queue dans la liste de reference
	if (referenceVide(R)) ajouter(p,R);
	else ajouterPage(p,R->suiv);
}

bool trouverPage (Page p, referenceDePage R) {		//Verifie si une page se trouve dans la liste
	if (referenceVide(R)) return false;
	else if (R->page.numeroPage == p.numeroPage) return true;
	else return trouverPage(p,R->suiv);
}

int positionPage(Page p, referenceDePage R) {			//Renvoi la position de la page dans la liste (return -1 si la page n'est pas trouvée)
	if (referenceVide(R) || not trouverPage(p,R)) return -1;
	else if (R->page.numeroPage == p.numeroPage) return 0;
	else return 1 + positionPage(p,R->suiv);
}

Page newDemandePage (referenceDePage &R) {			//Renvoi la page à inserer en mémoire et la supprime de la liste
	referenceDePage R1 = R;
	R = R->suiv;
	Page p = R1->page;
	delete R1; R1 = nullptr;
	return p;
}

void afficheReferencePage (referenceDePage R , int i) {
	if (not referenceVide(R)) {
		std::cout << "La " << i+1 << "ème page à inserer en Memoire : " << std::endl;
		affichePage(R->page); std::cout << std::endl;
		afficheReferencePage (R->suiv,++i);
	}
	else std::cout << "Il n'y a plus d'élément dans la liste d'attente (^_^)" << std::endl;
}
void afficheReferencePage (referenceDePage R) {			//Affiche les pages presentent dans la liste
	afficheReferencePage (R,0);
}

	/*	###########	CREATION D'UN ESPACE DE PAGINATION	###############	*/
const int tailleMemoire = 15;
using Disque = std::array<Page, tailleMemoire>;
struct Pagination {								//La structure contient la mémoire pouvant contenir les différentes pages et le nombre de ressources disponibles
	Disque memoire;
	int espaceLibre;
	int tailleMax;
	int nbVictime;
};

Pagination initPagination (int taille) {		//Initialise l'espace de traitement de page en déterminant le nombre de ressources disponibles (taille)
	Pagination P;
	P.espaceLibre = taille; P.tailleMax = taille; P.nbVictime = 0;
	return P;
}

bool ressourceVide(Pagination P)
{	return P.tailleMax == P.espaceLibre; }

bool trouveEspace (Pagination P) 				//Détermine s'il y a des l'espace dans la mémoire (Ressource disponible)
{	return P.espaceLibre > 0;  }

void decale(Pagination &P) {				//Décale tous les éléments de la memoire vers la gauche
	Page k = P.memoire[0];
	for (int i = 0; i < P.tailleMax-P.espaceLibre; i++)
		P.memoire[i] = P.memoire[i+1];
	P.memoire[(P.tailleMax-P.espaceLibre)-1] = k;
}
void decaleVictime(Pagination &P) {				//Décale tous les éléments de la memoire vers la gauche en accordant une chance à la victime (-- refVictime)
	--P.memoire[0].reference;
	Page k = P.memoire[0];
	for (int i = 0; i < P.tailleMax-P.espaceLibre; i++)
		P.memoire[i] = P.memoire[i+1];
	P.memoire[(P.tailleMax-P.espaceLibre)-1] = k;
}

void donneChance (Pagination &P) {				//Donne une chance à la page prise pour victime en fonction de sa reference (ref > 0)
	int i = 0; bool victimeTrouver = false;
	while (i < P.tailleMax-P.espaceLibre && victimeTrouver == false) {
		if (!refNull(P.memoire[i])) {
			decaleVictime(P);
			i = 0;
		} else victimeTrouver = true;
	}
}
int supprimeEnMemoire (Pagination &P) {			//Retourne la position de la page supprimée (la page supprimée doit toujours être dans la derniere colonne)
	if (not trouveEspace(P)) {
		donneChance(P);
		decale(P);
		return (P.tailleMax-P.espaceLibre)-1;
	} else return -1;
}

bool trouverPageMemoire(Page p, Pagination P) {		//Retourne si une page se trouve dans la mémoire
	for (int i = 0; i < P.tailleMax-P.espaceLibre; i++)
		if (P.memoire[i].numeroPage == p.numeroPage) return true;
	return false;
}

int positionPageMemoire (Page p, Pagination P) {	//Retourne la position de la page dans la mémoire, -1 sinon
	for (int i = 0; i < P.tailleMax-P.espaceLibre; i++)
		if (P.memoire[i].numeroPage == p.numeroPage) return i;
	return -1;
}

void inserePage(referenceDePage &R, Pagination &P) {		//Insère une page en mémoire en fonction des ressources disponibles
	if (not referenceVide(R)) {
		Page p = newDemandePage(R);
		if (trouveEspace(P) && not trouverPageMemoire(p,P)) {
			int n = P.tailleMax - P.espaceLibre;
			P.memoire[n] = p;
			--P.espaceLibre;
			inserePage(R,P);
		}
		else if (trouverPageMemoire(p,P)) {
			int n = positionPageMemoire(p,P);
			++P.memoire[n].reference;
			inserePage(R,P);
		}
		else {
			int sup = supprimeEnMemoire(P), i = P.nbVictime;
			if (i == 0) std::cout << "Il y a eu un " << i+1 << "re défaut de pages" << std::endl;
			else std::cout << "Il y a eu un " << i+1 << "ème défaut de pages" << std::endl;
			std::cout << "La page victime est la n°" << P.memoire[sup].numeroPage << " pour l'insertion de la page n°" << p.numeroPage << std::endl;
			P.memoire[sup] = p;
			++P.nbVictime;
			inserePage(R,P);
		}
	}	
}

void saisieRessourcePagination (Pagination &p) {
	int n;
	std::cout << "Veuillez saisir le nombre de ressource disponible sur le disque [1,15] : ";
	do {
		std::cin >> n;
		if (n < 1 || n > 15) std::cout << "Le nombre de ressource doit être compris entre [1,15] : ";
	} while (n < 1 || n > 15);
	p = initPagination(n);
	std::cout << "La pagination de seconde chance ayant " << p.espaceLibre << " ressources disponibles est créée " << std::endl;
}

void afficheRessourcePagination (Pagination P) {
	if (!ressourceVide(P)) {
		std::cout << "Il y a eu au total " << P.nbVictime << " défaut(s) de page(s). Affichons le contenu de la mémoire :" << std::endl;
		int espaceUtilise = P.tailleMax-P.espaceLibre;
		for (int i = 0; i < espaceUtilise; i++) {
			affichePage(P.memoire[i]);
			std::cout << std::endl;
		}
		std::cout << "Il y a " << P.espaceLibre << " ressources libres sur notre disque " << std::endl;
	}
}
void libereRessource (Pagination &P) {
	if (!ressourceVide(P)) {
		std::cout << "Libérons les ressources utilisées (^_^)" << std::endl;
		P.espaceLibre = P.tailleMax;
		std::cout << "Les ressources ont été libéré avec succès. L'espace libre est : " << P.espaceLibre << std::endl;
	}
	else std::cout << "La mémoire a été vidé, Merci pour votre patience" << std::endl;
}
/*
		#######################################
				PROGRAMME PRINCIPAL		
		#######################################
*/
int main () {
	std::cout << std::endl;
	std::cout << "###########################################################################################################" << std::endl;
	std::cout << "	Vous pouvez collez ça directement dans le terminal pour la Solution du (TD4)						" << std::endl;
	std::cout << "			20 1 2 3 4 2 1 5 6 2 1 2 3 7 6 3 2 1 2 3 6														" << std::endl;
	std::cout << "###########################################################################################################" << std::endl;
	std::cout << std::endl;

	std::cout << "DEBUT DE L'ALGORITHME DE PAGINATION DE LA SECONDE CHANCE" << std::endl;
	//		DECLARATION DES VARIABLES
	Page p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20;
	referenceDePage R;
	Pagination P;
	int n = 0;
	//		CRÉATION DES PAGES AVEC LES NUMEROS COMPRIS ENTRE [1,21]
	std::cout << "Veuillez déterminer le nombre de pages utiles (compris entre [1,21]) : ";
	do {
		std::cin >> n;	std::cout << std::endl;
		if (n < 1 || n > 21) std::cout << "Le nombre de pages doit être compris entre [1,21] : ";
	} while (n < 1 || n > 21);
	std::cout << "Créons les " << n << " pages utiles et insérons les dans la page de référencements (Methode FIFO) : " << std::endl;
	if (n > 0)	saisiePage(p0);
	if (n > 1)	saisiePage(p1);
	if (n > 2)	saisiePage(p2);
	if (n > 3)	saisiePage(p3);
	if (n > 4)	saisiePage(p4);
	if (n > 5)	saisiePage(p5);
	if (n > 6)	saisiePage(p6);
	if (n > 7)	saisiePage(p7);
	if (n > 8)	saisiePage(p8);
	if (n > 9)	saisiePage(p9);
	if (n > 10)	saisiePage(p10);
	if (n > 11)	saisiePage(p11);
	if (n > 12)	saisiePage(p12);
	if (n > 13)	saisiePage(p13);
	if (n > 14)	saisiePage(p14);
	if (n > 15)	saisiePage(p15);
	if (n > 16)	saisiePage(p16);
	if (n > 17)	saisiePage(p17);
	if (n > 18)	saisiePage(p18);
	if (n > 19)	saisiePage(p19);
	if (n > 20)	saisiePage(p20);
		std::cout << std::endl;
	//		CRÉATION D'UNE REFERENCE DE PAGES CONTENANT LA LISTE DE PAGES À INSERER EN MÉMOIRE
	initRef(R);
	if (n > 0)	ajouterPage(p0,R);
	if (n > 1)	ajouterPage(p1,R);
	if (n > 2)	ajouterPage(p2,R);
	if (n > 3)	ajouterPage(p3,R);
	if (n > 4)	ajouterPage(p4,R);
	if (n > 5)	ajouterPage(p5,R);
	if (n > 6)	ajouterPage(p6,R);
	if (n > 7)	ajouterPage(p7,R);
	if (n > 8)	ajouterPage(p8,R);
	if (n > 9)	ajouterPage(p9,R);
	if (n > 10)	ajouterPage(p10,R);
	if (n > 11)	ajouterPage(p11,R);
	if (n > 12)	ajouterPage(p12,R);
	if (n > 13)	ajouterPage(p13,R);
	if (n > 14)	ajouterPage(p14,R);
	if (n > 15)	ajouterPage(p15,R);	
	if (n > 16)	ajouterPage(p16,R);
	if (n > 17)	ajouterPage(p17,R);
	if (n > 18)	ajouterPage(p18,R);
	if (n > 19)	ajouterPage(p19,R);
	if (n > 20)	ajouterPage(p20,R);
	std::cout << "Affichons le contenu de la Référence de pages " << std::endl;
	afficheReferencePage(R);
	std::cout << std::endl;
	//		CREÉATION DE L'ESPACE DE PAGINATION DE LA SECONDE CHANCE AVEC DES RESSOURCES COMPRISES ENTRE [1,15]
	saisieRessourcePagination(P);
	std::cout << std::endl;
	inserePage(R,P); std::cout << std::endl;
	afficheRessourcePagination (P);	std::cout << std::endl;
	libereRessource(P);
	std::cout << std::endl;
	std::cout << "C'ÉTAIT L'ALGORITHME DE PAGINATION DE LA SECONDE CHANCE" << std::endl;
	
	return 0;
}
